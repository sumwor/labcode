root_subdir = 'Data Learning/';

jj=1;
% datafiles(jj).sub_dir = '170223/';
% datafiles(jj).logfile = '746-phase2r_DISCRIM.log';
% datafiles(jj).sstCells = []; 
% datafiles(jj).pvCells = []; 
% datafiles(jj).alphacorr = 0;

% jj=jj+1;
% datafiles(jj).sub_dir = '170303/';
% datafiles(jj).logfile = '746-phase2r_DISCRIM32.log';
% datafiles(jj).sstCells = []; 
% datafiles(jj).pvCells = []; 
% datafiles(jj).alphacorr = 0;

% jj=jj+1;
datafiles(jj).sub_dir = '170311/';
datafiles(jj).logfile = '746-HW_phase3_RULESWITCHING.log';
datafiles(jj).sstCells = []; 
datafiles(jj).pvCells = []; 
datafiles(jj).alphacorr = 0;